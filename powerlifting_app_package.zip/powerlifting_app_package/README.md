
# Powerlifting App Package (MVP)

This package contains the MVP documents and template JSONs for the powerlifting app.

## Structure
```
/docs
  PRD.md
  wireframes.pdf
/templates
  soviet_peak_6w.json
  deadlift_only_12w.json
  bench_only_12w.json
  sheiko_offseason_8w.json
  cube_method_3w.json
  template_schema.json
```

## Tech Stack (recommended)
- Mobile: **React Native (Expo, TypeScript)**
- Backend: **Node.js (NestJS/Express) + PostgreSQL (Prisma)** or **Supabase**
- Auth & Storage: Supabase
- Subscriptions: **RevenueCat** (handles iOS/Android billing)
- Analytics: Mixpanel/Amplitude; Crash Reporting: Sentry

## Load Calculation
```
load_kg = ceil((user_1rm_kg * percent_1rm) / 2.5) * 2.5
```
- Store internally in kg; convert to lb for UI if needed.

## Getting Started (Dev)
1. Import templates from `/templates`.
2. Implement onboarding → ask for 1RMs.
3. In session screen, compute loads using the rule above and show a rounding badge.
4. Gate templates/analytics behind Premium entitlement.

## License
All training content © Dave Richardson. All rights reserved.
